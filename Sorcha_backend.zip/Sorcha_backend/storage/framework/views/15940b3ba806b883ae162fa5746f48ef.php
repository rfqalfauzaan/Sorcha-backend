<?php $__env->startSection('container'); ?>
    <h1>Admin Dashboard</h1>
    <!-- Add your admin dashboard content here -->
    <p>Welcome to the admin dashboard!</p>
    <ul>
        <li>Dashboard Item 1</li>
        <li>Dashboard Item 2</li>
        <li>Dashboard Item 3</li>
    </ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alfa\Downloads\Compressed\Sorcha_backend\resources\views/home.blade.php ENDPATH**/ ?>