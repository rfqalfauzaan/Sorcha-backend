
<nav class="navbar navbar-expand-lg navbar-dark" style="background-color:#002365;">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">Sorcha Laundry</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="/">Dashboard</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/user">User</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/laundry">Laundry</a>
          </li>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/progress">Progress Laundry</a>
        </ul>
      </div>
    </div>
  </nav>
<?php /**PATH C:\Users\Alfa\Downloads\Compressed\dilaundry_backend\resources\views/partials/navbar.blade.php ENDPATH**/ ?>