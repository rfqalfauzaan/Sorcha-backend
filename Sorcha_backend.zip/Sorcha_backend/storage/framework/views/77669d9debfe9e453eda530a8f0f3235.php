<?php $__env->startSection('container'); ?>
<h1 class="text-center mb-4">Laundry</h1>
<table class="table">
    <a href="/tambahshop" type="button" class="btn btn-success">Tambah</a>
    <div class="row">
        <?php if($message= Session::get('success')): ?>
        <div class="alert alert-success" role="alert">
          <?php echo e($message); ?>

          </div>
        <?php endif; ?>
          <thead>
            <tr>
              <th scope="col">#</th>
              <th scope="col">name</th>
              <th scope="col">city</th>
              <th scope="col">location</th>
              <th scope="col">whatsapp</th>
              <th scope="col">rate</th>
              <th scope="col">description</th>
              <th scope="col">price</th>
            </tr>
          </thead>
          <tbody>

              <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                  <th scope="row"><?php echo e($shop->id); ?></th>
                  <td><?php echo e($shop->name); ?></td>
                  <td><?php echo e($shop->city); ?></td>
                  <td><?php echo e($shop->location); ?></td>
                  <td><?php echo e($shop->whatsapp); ?></td>
                  <td><?php echo e($shop->rate); ?></td>
                  <td><?php echo e($shop->description); ?></td>
                  <td><?php echo e($shop->price); ?></td>
                  <td>
                    <a href="/tampilshop/{$user->id}" type="button" class="btn btn-warning">Edit</a>
                      <button type="button" class="btn btn-danger">Delete</button>
                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </tbody>
        </table>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alfa\Downloads\Compressed\Sorcha-backend\Sorcha_backend\resources\views//shop/shop.blade.php ENDPATH**/ ?>