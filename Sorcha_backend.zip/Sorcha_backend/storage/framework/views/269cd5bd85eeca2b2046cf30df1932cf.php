<?php $__env->startSection('container'); ?>
    <h1 class="text-center mb-4">Edit User</h1>
    <div class="row justify-content-center">
      <div class="col-8">
        <div class="card">
            <div class="cardbody">
                <form action="/updateshop/<?php echo e($data); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Name</label>
                    <input type="text" name="name" class="form-control" id="name" aria-describedby="emailHelp" value="<?php echo e($data ? $data->name : ''); ?>">
                  </div>
                  <div class="mb-3">
                      <label for="exampleInputEmail1" class="form-label">location</label>
                      <input type="text" name="location" class="form-control" id="location" aria-describedby="emailHelp" value="<?php echo e($data ? $data->location : ''); ?>">
                    </div>
                    <div class="mb-3">
                      <label for="exampleInputEmail1" class="form-label">city</label>
                      <input type="text" name="city" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="city">
                    </div>
                    <div class="mb-3">
                      <label for="exampleInputEmail1" class="form-label">whatsapp</label>
                      <input type="text" name="whatsapp" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e($data ? $data->whatsapp : ''); ?>">
                    </div>
                    <div class="mb-3">
                      <label for="exampleInputEmail1" class="form-label">description</label>
                      <input type="text" name="description" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e($data ? $data->description : ''); ?>">
                    </div>
                    <div class="mb-3">
                      <label for="exampleInputEmail1" class="form-label">price</label>
                      <input type="double" name="price" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e($data ? $data->price : ''); ?>">
                    </div>
                    <div class="mb-3">
                      <label for="exampleInputEmail1" class="form-label">rate</label>
                      <input type="double" name="rate" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e($data ? $data->rate : ''); ?>">
                    </div>

                  <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alfa\Downloads\Compressed\Sorcha-backend\Sorcha_backend\resources\views//shop/tampilshop.blade.php ENDPATH**/ ?>