<!-- resources/views/admin/dashboard.blade.php -->

@extends('layouts.admin')

@section('content')
    <div class="container mt-5">
        <h1>Welcome to Admin Dashboard</h1>
        <!-- Tambahkan konten dashboard sesuai kebutuhan -->
    </div>
@endsection
