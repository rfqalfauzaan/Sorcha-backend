<!-- resources/views/shops/edit.blade.php -->



<?php $__env->startSection('content'); ?>
    <h1>Edit Shop</h1>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('shops.update', $shop->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="form-group">
            <label for="image">Image:</label>
            <input type="text" name="image" class="form-control" value="<?php echo e($shop->image); ?>" required>
        </div>

        <div class="form-group">
            <label for="name">Name:</label>
            <input type="text" name="name" class="form-control" value="<?php echo e($shop->name); ?>" required>
        </div>

        <div class="form-group">
            <label for="location">Location:</label>
            <input type="text" name="location" class="form-control" value="<?php echo e($shop->location); ?>" required>
        </div>

        <div class="form-group">
            <label for="city">City:</label>
            <input type="text" name="city" class="form-control" value="<?php echo e($shop->city); ?>" required>
        </div>

        <div class="form-group">
            <label for="delivery">Delivery:</label>
            <input type="checkbox" name="delivery" value="1" <?php echo e($shop->delivery ? 'checked' : ''); ?>>
        </div>

        <div class="form-group">
            <label for="pickup">Pickup:</label>
            <input type="checkbox" name="pickup" value="1" <?php echo e($shop->pickup ? 'checked' : ''); ?>>
        </div>

        <div class="form-group">
            <label for="whatsapp">WhatsApp:</label>
            <input type="text" name="whatsapp" class="form-control" value="<?php echo e($shop->whatsapp); ?>" required>
        </div>

        <div class="form-group">
            <label for="description">Description:</label>
            <textarea name="description" class="form-control" required><?php echo e($shop->description); ?></textarea>
        </div>

        <div class="form-group">
            <label for="price">Price:</label>
            <input type="number" name="price" class="form-control" value="<?php echo e($shop->price); ?>" required>
        </div>

        <div class="form-group">
            <label for="rate">Rate:</label>
            <input type="number" name="rate" class="form-control" value="<?php echo e($shop->rate); ?>" required>
        </div>

        <button type="submit" class="btn btn-primary">Update</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alfa\Downloads\Compressed\Sorcha-backend\Sorcha_backend\resources\views/shops/edit.blade.php ENDPATH**/ ?>