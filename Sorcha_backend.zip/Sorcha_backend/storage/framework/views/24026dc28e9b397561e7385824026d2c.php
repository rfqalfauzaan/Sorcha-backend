<!-- resources/views/laundries/index.blade.php -->



<?php $__env->startSection('content'); ?>
    <h1   style="text-align: center">Laundry Proggress </h1>

    <a href="<?php echo e(route('laundries.create')); ?>" class="btn btn-primary">Create Laundry</a>

    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>User ID</th>
                <th>Shop ID</th>
                <th>Weight</th>
                <th>Pickup Address</th>
                <th>Delivery Address</th>
                <th>Total</th>
                <th>Description</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $laundries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $laundry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($laundry->id); ?></td>
                    <td><?php echo e($laundry->user_id); ?></td>
                    <td><?php echo e($laundry->shop_id); ?></td>
                    <td><?php echo e($laundry->weight); ?></td>
                    <td><?php echo e($laundry->pickup_address); ?></td>
                    <td><?php echo e($laundry->delivery_address); ?></td>
                    <td><?php echo e($laundry->total); ?></td>
                    <td><?php echo e($laundry->description); ?></td>
                    <td><?php echo e($laundry->status); ?></td>
                    <td>
                        <a href="<?php echo e(route('laundries.edit', $laundry->id)); ?>" class="btn btn-warning">Edit</a>
                        <a href="<?php echo e(route('laundries.destroy', $laundry->id)); ?>" class="btn btn-danger" onclick="event.preventDefault(); document.getElementById('delete-form-<?php echo e($laundry->id); ?>').submit();">Delete</a>
                        <form id="delete-form-<?php echo e($laundry->id); ?>" action="<?php echo e(route('laundries.destroy', $laundry->id)); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alfa\Downloads\Compressed\Sorcha-backend\Sorcha_backend\resources\views/laundries/index.blade.php ENDPATH**/ ?>