@extends('layouts.main')

@section('container')
    <h1>Admin Dashboard</h1>
    <!-- Add your admin dashboard content here -->
    <p>Welcome to the admin dashboard!</p>
    <ul>
        <li>Dashboard Item 1</li>
        <li>Dashboard Item 2</li>
        <li>Dashboard Item 3</li>
    </ul>
@endsection
