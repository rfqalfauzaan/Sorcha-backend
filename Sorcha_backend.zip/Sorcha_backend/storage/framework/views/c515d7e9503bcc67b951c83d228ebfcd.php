<?php $__env->startSection('container'); ?>
<h1 class="text-center mb-4">Laundry progress</h1>
<table class="table">
    <a href="/tambahlaundry" type="button" class="btn btn-success">Tambah</a>
    <div class="row">
        <?php if($message= Session::get('success')): ?>
        <div class="alert alert-success" role="alert">
          <?php echo e($message); ?>

          </div>
        <?php endif; ?>
          <thead>
            <tr>
              <th scope="col">#</th>
              <th scope="col">User Id</th>
              <th scope="col">Shop Id</th>
              <th scope="col">Berat</th>
              <th scope="col">pickup</th>
              <th scope="col">Delivery</th>
              <th scope="col">total</th>
              <th scope="col">Description</th>
            </tr>
          </thead>
          <tbody>

              <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                  <th scope="row"><?php echo e($dr->id); ?></th>
                  <td><?php echo e($dr->user_id); ?></td>
                  <td><?php echo e($dr->shop_id); ?></td>
                  <td><?php echo e($dr->whight); ?></td>
                  <td><?php echo e($dr->pickup_address); ?></td>
                  <td><?php echo e($dr->delivery_address); ?></td>
                  <td><?php echo e($dr->total); ?></td>
                  <td><?php echo e($dr->description); ?></td>
                  <td><?php echo e($dr->status); ?></td>
                  <td>
                    <a href="/tampillaundry/{$data->id}" type="button" class="btn btn-warning">Edit</a>
                      <button type="button" class="btn btn-danger">Delete</button>
                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </tbody>
        </table>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alfa\Downloads\Compressed\Sorcha-backend\Sorcha_backend\resources\views//laundry/laundry.blade.php ENDPATH**/ ?>