<?php $__env->startSection('container'); ?>
    <h1>User</h1>
    <a href="tambahuser" class="btn btn-success">Tambah</a>
    <div class="row">
        <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success" role="alert">
           <?php echo e($message); ?>

          </div>
        <?php endif; ?>
        <table class="table">
            <thead>
              <tr>
                <th scope="col">Id</th>
                <th scope="col">username</th>
                <th scope="col">email</th>
              </tr>
            </thead>
            <tbody>
                <tr>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e($user['id']); ?></td>
                <td><?php echo e($user['username']); ?></td>
                <td><?php echo e($user['email']); ?></td>
                <td>
                    <a href="/tampiluser/{$user->id}" type="button" class="btn btn-warning">Edit</a>
                    <button type="button" class="btn btn-danger">Delete</button>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alfa\Downloads\Compressed\Sorcha_backend\resources\views/user.blade.php ENDPATH**/ ?>