   <?php $__env->startSection('container'); ?>
    <h1>Halaman Dashboard</h1>
   <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alfa\Downloads\Compressed\dilaundry_backend\resources\views/home.blade.php ENDPATH**/ ?>