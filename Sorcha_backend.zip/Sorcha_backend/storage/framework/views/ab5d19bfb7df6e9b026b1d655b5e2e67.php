<?php $__env->startSection('container'); ?>
    <h1 class="text-center mb-4">Edit User</h1>
    <div class="row justify-content-center">
      <div class="col-8">
        <div class="card">
            <div class="cardbody">
                <form action="/updateuser/<?php echo e($data->id ?? 'code notfound'); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="exampleInputPassword1" class="form-label">Username</label>
                        <input type="text" name="username" class="form-control" id="username" value="<?php echo e($data->username ?? 'code not found'); ?>">
                      </div>
                    <div class="mb-3">
                      <label for="exampleInputEmail1" class="form-label">Email address</label>
                      <input type="email" name="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e($data->email ?? 'code not found'); ?>">
                    </div>
                    <div class="mb-3">
                      <label for="exampleInputPassword1" class="form-label">Password</label>
                      <input type="password" name="password" class="form-control" id="exampleInputPassword1" value="<?php echo e($data->password ?? 'code not found'); ?>">
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                  </form>
            </div>
        </div>
      </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alfa\Downloads\Compressed\Sorcha_backend\resources\views/tampiluser.blade.php ENDPATH**/ ?>